<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('prodi', function (Blueprint $table) {
            $table->id('id_prodi');
            $table->enum('jenjang', ['D3','D4','S2']);
            $table->enum('nama_prodi', ['IF','TRPL','GM','TP','TRM','RKS']);
            $table->string('nik_kps', 20)->nullable()->unique();
            $table->foreign('nik_kps')->references('nik')->on('dosen')->onDelete('set null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('prodi');
    }
};
